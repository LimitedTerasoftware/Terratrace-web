import HotoSurvey from '../components/Tables/HotoSurvey';

const HotoTables = () => {
  return (
    <>
      <div className="flex flex-col gap-10">
        <HotoSurvey/>
      </div>
    </>
  );
};

export default HotoTables;
