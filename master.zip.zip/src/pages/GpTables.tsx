import GpSurvey from '../components/Tables/GpSurvey';

const GpTables = () => {
  return (
    <>
    <div className="flex flex-col gap-10">
        <GpSurvey/>
      </div>
    </>
  );
};

export default GpTables;
