import AerailSurvey from '../../components/Tables/AerailSurvey';

const AerailTables = () => {
  return (
    <>
      <div className="flex flex-col gap-10">
        <AerailSurvey/>
      </div>
    </>
  );
};

export default AerailTables;
