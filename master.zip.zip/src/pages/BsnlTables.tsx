import BsnlSurvey from '../components/Tables/BsnlSurvey';

const BsnlTables = () => {
  return (
    <>
      <div className="flex flex-col gap-10">
        <BsnlSurvey/>
      </div>
    </>
  );
};

export default BsnlTables;
